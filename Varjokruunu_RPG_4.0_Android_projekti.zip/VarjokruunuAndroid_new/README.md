# Varjokruunu RPG 4.0

Android WebView app for the branching Varjokruunu fantasy RPG.

## Version 4.0
- 20+ branching story decision points
- Side quests that affect allies and endings
- Ally deaths and betrayal paths
- Multiple regions and exploration
- Six major ending variants based on previous choices
- Finnish and English
- Save/load in localStorage

Build with Gradle 8.13 and Java 17.
