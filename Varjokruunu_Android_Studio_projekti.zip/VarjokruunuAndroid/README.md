# Varjokruunu — Android APK

Valmis Android Studio -projekti, joka paketoi Varjokruunu HTML/JavaScript-RPG:n natiiviksi Android-sovellukseksi WebViewiin.

## APK:n rakentaminen
1. Asenna Android Studio.
2. Avaa tämä kansio Android Studiossa.
3. Anna Gradlen ladata Android Gradle Pluginin ja riippuvuudet.
4. Valitse **Build → Build APK(s)**.
5. APK löytyy `app/build/outputs/apk/debug/app-debug.apk`.

Sovellus ei tarvitse internet-yhteyttä pelin pelaamiseen. Tallennus käyttää selaimen localStoragea sovelluksen sisällä.
